package com.example.githubuserapp.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import com.example.githubuserapp.data.database.FavoriteRoomDatabase
import com.example.githubuserapp.data.database.FavoriteUser
import com.example.githubuserapp.data.repository.FavoriteRepository

class FavoriteViewModel(application: Application) : AndroidViewModel(application) {
    private val repository : FavoriteRepository =
        FavoriteRepository(FavoriteRoomDatabase.getInstance(application).FavoriteDAO())

    var favoriteUser: LiveData<List<FavoriteUser>> = repository.getAllFavorite()

    fun insert(user: FavoriteUser){
        repository.insert(user, true)
    }

    fun delete(user: FavoriteUser){
        repository.delete(user, true)
    }

    fun getFavUsername (user: String): LiveData<FavoriteUser>{
        return repository.getFavUsername(user)
    }

}