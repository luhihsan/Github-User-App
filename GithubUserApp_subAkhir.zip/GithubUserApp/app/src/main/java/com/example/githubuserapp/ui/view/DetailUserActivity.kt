package com.example.githubuserapp.ui.view

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import androidx.annotation.StringRes
import androidx.lifecycle.ViewModelProvider
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.example.githubuserapp.R
import com.example.githubuserapp.adapter.SectionPagerAdapter
import com.example.githubuserapp.data.database.FavoriteUser
import com.example.githubuserapp.data.response.DetailUserResponse
import com.example.githubuserapp.databinding.ActivityDetailUserBinding
import com.example.githubuserapp.ui.viewmodel.DetailViewModel
import com.example.githubuserapp.ui.viewmodel.FavoriteViewModel
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import java.lang.StringBuilder

class DetailUserActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailUserBinding
    private val detailViewModel: DetailViewModel by viewModels<DetailViewModel>()

    companion object {
         val EXTRA_LOGIN ="extra_login"

        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.tab_text_followers,
            R.string.tab_text_followings
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val mFavoriteViewModel= ViewModelProvider(this)[FavoriteViewModel::class.java]
        detailViewModel.detailUser.observe(this){DetailUser ->
            setDetailUser(DetailUser)
            var isFav = false
            DetailUser.login.let{
                if (it != null) {
                    mFavoriteViewModel.getFavUsername(it).observe(this){ favoriteUser->
                        if (favoriteUser != null && favoriteUser.isFav){
                            isFav = true
                            binding.fabFav.setImageResource(R.drawable.ic_fav)
                        }else{
                            isFav = false
                            binding.fabFav.setImageResource(R.drawable.ic_fav_null)
                        }
                    }
                }
            }
            binding.fabFav.setOnClickListener{
                val insert = FavoriteUser(
                    id = DetailUser.id,
                    login = DetailUser.login,
                    avatarUrl = DetailUser.avatarUrl,
                    isFav = !isFav
                )
                val delete = FavoriteUser(
                    id = DetailUser.id,
                    login = DetailUser.login,
                    avatarUrl = DetailUser.avatarUrl,
                    isFav = isFav
                )
                if(isFav){
                    mFavoriteViewModel.delete(delete)
                    Toast.makeText(this, "User Dihapus Dari Daftar Favorit", Toast.LENGTH_SHORT).show()
                }else{
                    mFavoriteViewModel.insert(insert)
                    Toast.makeText(this, "User Ditambah Dari Daftar Favorit", Toast.LENGTH_SHORT).show()
                }
                isFav = !isFav
            }
        }


        val username = intent.getStringExtra(EXTRA_LOGIN)
        binding.textViewUsername.text = username

        username?.let { detailViewModel.getUserDetail(it) }
        detailViewModel.isLoading.observe(this){
            isLoading -> showLoading(isLoading)
        }

        supportActionBar?.elevation = 0f

        supportActionBar?.apply {
            title = "Detail User Github"
            setDisplayHomeAsUpEnabled(true)
        }

        detailViewModel.detailUser.observe(this) { detailUser ->
            setDetailUser(detailUser)}

        val SectionPagerAdapter = username?.let { SectionPagerAdapter(this, it) }
        val viewPager: ViewPager2 = binding.viewPager
        viewPager.adapter = SectionPagerAdapter
        val tabs: TabLayout = binding.tabs
        TabLayoutMediator(tabs, viewPager) { tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()

    }

    private fun setDetailUser(detailUser : DetailUserResponse){
        binding.textViewUsername.text = detailUser.login
        binding.textViewName.text = detailUser.name

        Glide.with(binding.root.context)
            .load(detailUser.avatarUrl)
            .into(binding.imageView)

        binding.tvFollowers.text = StringBuilder(detailUser.followers.toString()).append("Followers")
        binding.tvFollowing.text = StringBuilder(detailUser.following.toString()).append("Followings")

    }

    override fun onBackPressed() {
        super.onBackPressed()
        startActivity(Intent(this@DetailUserActivity, MainActivity::class.java))
        finish()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            android.R.id.home ->{
                onBackPressed()
                startActivity(Intent((this@DetailUserActivity), MainActivity::class.java))
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }


    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

}
