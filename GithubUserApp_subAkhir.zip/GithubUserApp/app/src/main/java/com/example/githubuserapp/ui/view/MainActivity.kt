package com.example.githubuserapp.ui.view

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.githubuserapp.R
import com.example.githubuserapp.adapter.UserAdapter
import com.example.githubuserapp.data.datastore.SettingPreferences
import com.example.githubuserapp.data.datastore.dataStore
import com.example.githubuserapp.data.response.GithubResponse
import com.example.githubuserapp.data.response.ItemsItem
import com.example.githubuserapp.data.retrofit.ApiConfig
import com.example.githubuserapp.databinding.ActivityMainBinding
import com.example.githubuserapp.ui.viewmodel.SettingViewModel
import com.example.githubuserapp.ui.viewmodel.SettingViewModelFactory
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private lateinit var binding : ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding =ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        supportActionBar?.hide()

        val pref = SettingPreferences.getInstance(application.dataStore)
        val main = ViewModelProvider(this, SettingViewModelFactory(pref)).get(
            SettingViewModel::class.java
        )

        main.getThemeSettings().observe(this) { isDarkModeActive: Boolean ->
            if (isDarkModeActive) {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
            } else {
                AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)
            }
        }

        val layoutManager = LinearLayoutManager(this)
        binding.rvUser.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(this, layoutManager.orientation)
        binding.rvUser.addItemDecoration(itemDecoration)

        findUser()

        with(binding){
            searchView.setupWithSearchBar(searchBar)
            searchBar.inflateMenu(R.menu.about)
            searchView
                .editText
                .setOnEditorActionListener { textView, actionId, event ->
                    var searchVal = searchBar.text
                    searchVal = searchView.text
                    searchView.hide()
                    ShowLoading(true)
                    findSearchUser(searchVal.toString())
                    Toast.makeText(this@MainActivity, searchView.text, Toast.LENGTH_SHORT).show()
                    false
                }
        }

        binding.searchBar.setOnMenuItemClickListener{ menuItem ->
            when(menuItem.itemId){
                R.id.favorite_page ->{
                    val fav = Intent(this@MainActivity, FavoriteActivity::class.java)
                    startActivity(fav)
                    true
                }
                R.id.seting_page -> {
                    val settings = Intent(this@MainActivity, SettingsActivity::class.java)
                    startActivity(settings)
                    true
                }
                else -> false
            }

        }

    }

    private fun findUser() {
        ShowLoading(true)
        val client = ApiConfig.getApiConfig().searchGitHubUser("a")
        client.enqueue(object : Callback<GithubResponse> {
            override fun onResponse(
                call: Call<GithubResponse>,
                response: Response<GithubResponse>
            ) {
                ShowLoading(false)
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null) {
                        setUserData(responseBody.items)
                        Log.d(TAG, "onResponse: ")
                    }
                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }
            override fun onFailure(call: Call<GithubResponse>, t: Throwable) {
                ShowLoading(false)
                Log.e(TAG, "onFailure: ${t.message}")
            }
        })
    }

    private fun findSearchUser(q: String) {
        ShowLoading(true)
        val client = ApiConfig.getApiConfig().searchGitHubUser(q)
        client.enqueue(object : Callback<GithubResponse> {
            override fun onResponse(
                call: Call<GithubResponse>,
                response: Response<GithubResponse>
            ) {
                ShowLoading(false)
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    if (responseBody != null) {
                        setUserData(responseBody.items)
                        Log.d(TAG, "onResponse: ")
                    }
                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }
            override fun onFailure(call: Call<GithubResponse>, t: Throwable) {
                ShowLoading(false)
                Log.e(TAG, "onFailure: ${t.message}")
            }
        })
    }

    private fun setUserData(account: List<ItemsItem?>?) {
        val adapter = UserAdapter()
        adapter.submitList(account)
        binding.rvUser.adapter = adapter
    }

    private fun ShowLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    companion object {
        private const val TAG = "MainActivity"
    }

}