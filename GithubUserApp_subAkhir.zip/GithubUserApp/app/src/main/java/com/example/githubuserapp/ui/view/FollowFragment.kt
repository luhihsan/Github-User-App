package com.example.githubuserapp.ui.view

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.githubuserapp.adapter.UserAdapter
import com.example.githubuserapp.data.response.ItemsItem
import com.example.githubuserapp.databinding.FragmentFollowBinding
import com.example.githubuserapp.ui.viewmodel.FollowViewModel

class FollowFragment : Fragment() {

    private val FollowViewModel by viewModels<FollowViewModel>()
    private lateinit var binding: FragmentFollowBinding
    private var position: Int = 0
    private var username: String? = null

    companion object {
        const val POSITION = "position"
        const val USERNAME = "username"
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentFollowBinding.inflate(inflater, container, false)

        val LayoutManager = LinearLayoutManager(requireContext())
        binding.rvFollow.layoutManager = LayoutManager

        val itemDecoration = DividerItemDecoration(requireContext(), LayoutManager.orientation)
        binding.rvFollow.addItemDecoration(itemDecoration)

        arguments?.let {
            position = it.getInt(POSITION)
            username = it.getString(USERNAME)
        }

        FollowViewModel.isLoading.observe(viewLifecycleOwner) { isLoading ->
            ShowLoading(isLoading)
        }

        FollowViewModel.followers.observe(viewLifecycleOwner) { followers ->
            ShowFollow(followers)
        }

        if (position == 1) {
            FollowViewModel.findFollowers(username ?: "")
        } else {
            FollowViewModel.findFollowings(username ?: "")
        }
        return binding.root
    }

    private fun ShowFollow(account: List<ItemsItem>) {
        val adapter = UserAdapter()
        adapter.submitList(account)
        binding.rvFollow.adapter = adapter
    }

    private fun ShowLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }


}