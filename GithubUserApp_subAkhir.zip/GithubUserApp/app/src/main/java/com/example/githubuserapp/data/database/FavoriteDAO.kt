package com.example.githubuserapp.data.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface FavoriteDAO {
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insert(user: FavoriteUser)

    @Delete
    fun delete(user: FavoriteUser)

    @Query("SELECT * FROM UserFav ORDER BY id ASC")
    fun getAllFavUsers(): LiveData<List<FavoriteUser>>

    @Query("SELECT * FROM UserFav WHERE login = :username AND isFav = 1")
    fun getFavUsername(username: String): LiveData<FavoriteUser>
}