package com.example.githubuserapp.ui.view

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.githubuserapp.adapter.FavoriteAdapter
import com.example.githubuserapp.data.response.ItemsItem
import com.example.githubuserapp.databinding.ActivityFavoriteBinding
import com.example.githubuserapp.ui.viewmodel.FavoriteViewModel
import com.example.githubuserapp.ui.viewmodel.ViewModelFactory


class FavoriteActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFavoriteBinding
    private lateinit var mFavoriteViewModel : FavoriteViewModel
    private lateinit var mFavoriteAdapter : FavoriteAdapter

    @SuppressLint("NotifyDataChanged")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding =ActivityFavoriteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val favoriteModelFactory = ViewModelFactory(application)
        mFavoriteViewModel =ViewModelProvider(this, favoriteModelFactory).get(FavoriteViewModel::class.java)

        val rv_favorite = binding.rvFav
        mFavoriteAdapter = FavoriteAdapter { favoriteUser ->
            val intentFav = Intent(this, DetailUserActivity::class.java)
            intentFav.putExtra("username", favoriteUser.login)
            startActivity(intentFav)
        }

        rv_favorite.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = mFavoriteAdapter
        }

        mFavoriteViewModel.favoriteUser.observe(this){userFav ->
            val items = arrayListOf<ItemsItem>()
            userFav.map{
                val item_fav = ItemsItem(login = it.login, avatarUrl = it.avatarUrl, id = it.id)
                items.add(item_fav)
            }
            mFavoriteAdapter.submitList(userFav)
            mFavoriteAdapter.notifyDataSetChanged()
        }

        supportActionBar?.apply {
            title = "Favorite Github User"
            setDisplayHomeAsUpEnabled(true)
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId){
            android.R.id.home->{
                onBackPressed()
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }
}