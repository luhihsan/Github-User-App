package com.example.githubuserapp.data.repository

import android.util.Log
import androidx.lifecycle.LiveData
import com.example.githubuserapp.data.database.FavoriteDAO
import com.example.githubuserapp.data.database.FavoriteUser
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class FavoriteRepository (
    private val mFavDao: FavoriteDAO,
    private val executorService: ExecutorService = Executors.newSingleThreadExecutor()
){
    fun getAllFavorite(): LiveData<List<FavoriteUser>> {
        return mFavDao.getAllFavUsers()
    }

    fun insert(user: FavoriteUser, favState:Boolean) {
        executorService.execute{
            user.isFav = favState
            mFavDao.insert(user)
        }
    }

    fun delete(user: FavoriteUser, favState:Boolean){
        executorService.execute{
            user.isFav = favState
            mFavDao.delete(user)
            Log.d("Repository", "Delete : ${user.login}")
        }
    }
    fun getFavUsername(username : String): LiveData<FavoriteUser> {
        return mFavDao.getFavUsername(username)
    }
}


